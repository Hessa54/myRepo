import Foundation

print("What is the quote?")
let input = readLine()

print("woh said it?")
let str = readLine()

print( "\(input!), '\(str!)'")

