import Foundation

print("What is the first number?")
let num1 = Int(readLine()!) /* The initial value = 1 if the user didn't enter anything */

print("What is the second number?")
let num2 = Int(readLine()!) /* The initial value = 1 if the user didn't enter anything */


print("\n")
print("\(num1!) + \(num2!) = \(num1! + num2!)")

print("\(num1!) - \(num2!) = \(num1! - num2!)")

print("\(num1!) * \(num2!) = \(num1! * num2!)")

print("\(num1!) / \(num2!) = \(num1! / num2!)")
