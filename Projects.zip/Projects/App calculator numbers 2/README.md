# A02- Weekend Assignment 

## 1- Assignment🚀
### Simple Math
Write a Swift program that prompts two numbers from the user and then performs basic arithmetic operations as shown in the example output

#### Example📑
```
What is the first number?
5
What is the second number?
5
```

#### Output✅
```
5 + 5 = 10

5 - 5 = 0
	
5 * 5 = 25

5 / 5 = 1
```

## 2- Assignment🚀
### Seconds to Minutes
Write a Swift program that receives seconds from the user and then converts them to minutes

#### Example📑
```
please insert the seconds
60
```

#### Output✅
```
60 seconds is 1 minute
```

## 3- Assignment🚀
### Calculate the Area of the Rectangle
Write a Swift program that prompts two numbers from the user (Width and Height of a rectangle), then calculate the area of the rectangle

#### Example📑
```
please enter the height of the rectangle:
10

please enter the width of the rectangle:
10
```

#### Output✅
```
The calculated area of the rectangle is: 100
```


## 4- Assignment🚀
### Driving License
Write a Swift program that prints the following sentences:

If the user's is older or equal to 18 years old
``` "You can get a driver's license" ```

If the user's age is under 18 years old
``` "Sorry, you can't get a driver's license" ```


### Deadline 🗓
7th Aug 2022 10:00 AM


