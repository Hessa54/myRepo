# A03-SayHelloApp

Develop an application that receives from the user his first and last name and then displays a welcome message


![IMG_0081](https://user-images.githubusercontent.com/82675633/183300936-c06c873a-e565-4a44-a947-6aa17de7f941.jpg)

### Deadline 🗓

8th Aug 2022 10:00 AM
