//
//  ViewController.swift
//  userInterface
//
//  Created by Hessa on 14/01/1444 AH.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var paswword: UITextField!
    @IBOutlet weak var masseglabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func bressedbutton(_ sender: Any) {
        if userName.text?.isEmpty==true{
            masseglabel.text = "ادخل اسم المستخدم"
        }
        else{
            print("There is a value")
            if let user=userName.text, let pass=paswword.text {
                if user=="Hessa" && pass=="123" {
                    self.view.backgroundColor = .green
                   
                }
                else {
                    self.view.backgroundColor = .red
                    masseglabel.text = "اسم المستخدم او كلمة المرور غير صحيحة"
                }
            }
        }
    }
}

        
        
        
        

    

