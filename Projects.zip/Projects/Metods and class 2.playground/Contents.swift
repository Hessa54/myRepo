import UIKit

struct Student {
    var name:String
    var age:Int
    var edcation:String
    var id:Int
}
var namee = Student(name:"hessa", age: 12, edcation: "baclr", id: 32332)

print(namee.age)
print(namee)

if(namee.age < 29){
    print("your")
}

 struct Ppersone {
    var hair:String
    var age:Int
    var edction:String
}
var nameee = Ppersone(hair:"short", age: 24, edction: "baclor`s")

if(nameee.age < 29){
   print("your older")
}

if nameee.edction == "baclor`s"
{
    print("your older")
}







struct post {
    var title:String
    var comment:String
    var like:Int
    func DISPLAYLIKE(){
        print("3")
    }
    mutating func DDLIKE(){
        like += 1
    }

}
var post1 = post(title: "d", comment: "f", like: 1)
var post2 = post(title: "i", comment: "k", like: 1)


var pos3 = post1


post1.DISPLAYLIKE()

post1.DDLIKE()

post1.DDLIKE()








class Pmerson {
    var name:String = ""
    var age: Int = 1
    var Tail: Double = 0.0

    func sayHello() {
        print("Hello, frined")
    }

}

var person = Pmerson()
person.age = 18

person.sayHello()
print("persone \(person.age)")


class TuwwaiqLabel{
    var value:String = ""
    let hight:Double = 0.0
    let width:Double = 0.0
    let textcolor:String = ""
    let backgroud:String = ""
    let font:String = ""
    func restlabel1 (){
        value = "KG"

    }
}
var age = TuwwaiqLabel()
age.value = "22"
print("your age" , age.value)
age.restlabel1()
print("your age" , age.value)
//---------------------------------------------------
//
//optional
var city: String? = "jkk"

city = nil
// ? force unwrap
print(city!)
// ? defult value
print(city ?? "er")
// optional binding
if let temp = city {
    print(temp)
}else {
    print("no value in city")
}

var num: Int?
var num1: Int?
num = 2
num1 = 3
var reesult = (num! + num1!)




// optional chaning
struct PPerson{
    var age: Int
    var resdidance: Resdidance?
    
}
struct Resdidance {
    var address: Address?
}
struct Address {
    var bulidngname: String?
    var stretnumber: String?
    var apartmentnumber: String?
}

var Hessa = PPerson(age: 20)
let theres = Resdidance()
let aprt = Address()



